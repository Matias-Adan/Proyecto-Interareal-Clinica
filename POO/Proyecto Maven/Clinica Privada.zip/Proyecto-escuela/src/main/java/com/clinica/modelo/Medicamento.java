package com.clinica.modelo;

public class Medicamento {
	private int idMedicamento;
	private String nombre;
	private String descripcion;
	private int stockAnual;
	private int stockMinimo;
	
	public Medicamento(int idMedicamento, String nombre, String descripcion, int stockAnual, int stockMinimo) {
		this.idMedicamento = idMedicamento;
		this.nombre = nombre;
		this.descripcion = descripcion;
		this.stockAnual = stockAnual;
		this.stockMinimo = stockMinimo;
	}

	public int getIdMedicamento() {
		return idMedicamento;
	}

	public void setIdMedicamento(int idMedicamento) {
		this.idMedicamento = idMedicamento;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public int getStockAnual() {
		return stockAnual;
	}

	public void setStockAnual(int stockAnual) {
		this.stockAnual = stockAnual;
	}

	public int getStockMinimo() {
		return stockMinimo;
	}

	public void setStockMinimo(int stockMinimo) {
		this.stockMinimo = stockMinimo;
	}
	
	
}
