package com.clinica.dao;

import java.util.List;

import com.clinica.modelo.Rol;

public interface IRolDao {
	boolean insertar(IRolDao r);
	List<IRolDao> listar();
	boolean actualizar(IRolDao r);
	boolean eliminar(int id);
}
