package com.clinica.dao;

import java.util.List;

import com.clinica.modelo.Turno;

public interface ITurnoDao {
	boolean insertar(ITurnoDao t);
	List<ITurnoDao> listar();
	boolean actualizar(ITurnoDao t);
	boolean eliminar(int id);
}
