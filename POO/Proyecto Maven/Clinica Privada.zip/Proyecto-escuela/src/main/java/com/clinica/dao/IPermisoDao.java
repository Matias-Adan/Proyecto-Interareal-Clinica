package com.clinica.dao;

import java.util.List;

import com.clinica.modelo.Permiso;

public interface IPermisoDao {
	boolean insertar(IPermisoDao p);
	List<IPermisoDao> listar();
	boolean actualizar(IPermisoDao p);
	boolean eliminar(int id);
}