package com.clinica.dao;

import java.util.List;
import com.clinica.modelo.Habitacion;

public interface IHabitacionDao {
	boolean insertar(IHabitacionDao h);
	List<IHabitacionDao> listar();
	boolean actualizar(IHabitacionDao h);
	boolean eliminar(int id);
}
