package com.clinica.modelo;

import java.time.LocalDate;
import java.time.LocalTime;

public class Consulta {
	private int idConsulta;
	private LocalDate fecha;
	private LocalTime hora;
	private String motivo;
	private String diagnostico;
	private String obvservacion;
	private int historialId;
	private int empleadoId;
	
	public Consulta(int idConsulta, LocalDate fecha, LocalTime hora, String motivo, String diagnostico,
			String obvservacion, int historialId, int empleadoId) {
		this.idConsulta = idConsulta;
		this.fecha = fecha;
		this.hora = hora;
		this.motivo = motivo;
		this.diagnostico = diagnostico;
		this.obvservacion = obvservacion;
		this.historialId = historialId;
		this.empleadoId = empleadoId;
	}

	public int getIdConsulta() {
		return idConsulta;
	}

	public void setIdConsulta(int idConsulta) {
		this.idConsulta = idConsulta;
	}

	public LocalDate getFecha() {
		return fecha;
	}

	public void setFecha(LocalDate fecha) {
		this.fecha = fecha;
	}

	public LocalTime getHora() {
		return hora;
	}

	public void setHora(LocalTime hora) {
		this.hora = hora;
	}

	public String getMotivo() {
		return motivo;
	}

	public void setMotivo(String motivo) {
		this.motivo = motivo;
	}

	public String getDiagnostico() {
		return diagnostico;
	}

	public void setDiagnostico(String diagnostico) {
		this.diagnostico = diagnostico;
	}

	public String getObvservacion() {
		return obvservacion;
	}

	public void setObvservacion(String obvservacion) {
		this.obvservacion = obvservacion;
	}

	public int getHistorialId() {
		return historialId;
	}

	public void setHistorialId(int historialId) {
		this.historialId = historialId;
	}

	public int getEmpleadoId() {
		return empleadoId;
	}

	public void setEmpleadoId(int empleadoId) {
		this.empleadoId = empleadoId;
	}
	
	
}
