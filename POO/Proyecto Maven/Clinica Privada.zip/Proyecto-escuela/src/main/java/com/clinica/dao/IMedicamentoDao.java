package com.clinica.dao;

import java.util.List;

import com.clinica.modelo.Medicamento;

public interface IMedicamentoDao {
	boolean insertar(IMedicamentoDao m);
	List<IMedicamentoDao> listar();
	boolean actualizar(IMedicamentoDao m);
	boolean eliminar(int id);
}