package com.clinica.modelo;

import java.time.LocalDate;

public class Empleado {
	private int idEmpleado;
	private String nombre;
	private String apellido;
	private int dni;
	private LocalDate fechaNaciemiento;
	private int telefono;
	private String email;
	private int matricula;
	private int especialidadId;
	private int rolId;
	private int usuarioId;
	
	
	public Empleado(int idEmpleado, String nombre, String apellido, int dni, LocalDate fechaNaciemiento, int telefono,
			String email, int matricula, int especialidadId, int rolId, int usuarioId) {
		this.idEmpleado = idEmpleado;
		this.nombre = nombre;
		this.apellido = apellido;
		this.dni = dni;
		this.fechaNaciemiento = fechaNaciemiento;
		this.telefono = telefono;
		this.email = email;
		this.matricula = matricula;
		this.especialidadId = especialidadId;
		this.rolId = rolId;
		this.usuarioId = usuarioId;
	}


	public int getIdEmpleado() {
		return idEmpleado;
	}


	public void setIdEmpleado(int idEmpleado) {
		this.idEmpleado = idEmpleado;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public String getApellido() {
		return apellido;
	}


	public void setApellido(String apellido) {
		this.apellido = apellido;
	}


	public int getDni() {
		return dni;
	}


	public void setDni(int dni) {
		this.dni = dni;
	}


	public LocalDate getFechaNaciemiento() {
		return fechaNaciemiento;
	}


	public void setFechaNaciemiento(LocalDate fechaNaciemiento) {
		this.fechaNaciemiento = fechaNaciemiento;
	}


	public int getTelefono() {
		return telefono;
	}


	public void setTelefono(int telefono) {
		this.telefono = telefono;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public int getMatricula() {
		return matricula;
	}


	public void setMatricula(int matricula) {
		this.matricula = matricula;
	}


	public int getEspecialidadId() {
		return especialidadId;
	}


	public void setEspecialidadId(int especialidadId) {
		this.especialidadId = especialidadId;
	}


	public int getRolId() {
		return rolId;
	}


	public void setRolId(int rolId) {
		this.rolId = rolId;
	}


	public int getUsuarioId() {
		return usuarioId;
	}


	public void setUsuarioId(int usuarioId) {
		this.usuarioId = usuarioId;
	}
	
	
}
