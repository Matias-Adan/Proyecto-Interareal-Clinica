package com.clinica.dao;

import java.util.List;

import com.clinica.modelo.PermisoRol;

public interface IPermisoRolDao {
	boolean insertar(IPermisoRolDao p);
	List<IPermisoRolDao> listar();
	boolean actualizar(IPermisoRolDao p);
	boolean eliminar(int id);
}