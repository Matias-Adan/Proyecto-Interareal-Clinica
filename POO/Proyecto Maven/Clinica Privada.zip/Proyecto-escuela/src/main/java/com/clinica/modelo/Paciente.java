package com.clinica.modelo;

import java.time.LocalDate;

public class Paciente {
	private int idPaciente;
	private String nombre;
	private String apellido;
	private int dni;
	private LocalDate fechaNaciemiento;
	private int telefono;
	private String email;
	private int obraSocialId;
	private int usuarioId;

	public Paciente(int idPaciente, String nombre, String apellido, int dni, LocalDate fechaNaciemiento, int telefono, String email, int obraSocialId, int usuarioId) {
		this.idPaciente = idPaciente;
		this.nombre = nombre;
		this.apellido = apellido;
		this.dni = dni;
		this.fechaNaciemiento = fechaNaciemiento;
		this.telefono = telefono;
		this.email = email;
		this.obraSocialId = obraSocialId;
		this.usuarioId = usuarioId;
	}
	
	public void setIdPaciente() {
		this.idPaciente = this.idPaciente + 1;
	}

	public int getIdPaciente() {
		setIdPaciente();
		return this.idPaciente;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getNombre() {
		return this.nombre;
	}
	
	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public int getDni() {
		return dni;
	}

	public void setDni(int dni) {
		this.dni = dni;
	}

	public LocalDate getFechaNaciemiento() {
		return fechaNaciemiento;
	}

	public void setFechaNaciemiento(LocalDate fechaNaciemiento) {
		this.fechaNaciemiento = fechaNaciemiento;
	}

	public int getTelefono() {
		return telefono;
	}

	public void setTelefono(int telefono) {
		this.telefono = telefono;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getObraSocialId() {
		return obraSocialId;
	}

	public void setObraSocialId(int obraSocialId) {
		this.obraSocialId = obraSocialId;
	}

	public int getUsuarioId() {
		return usuarioId;
	}

	public void setUsuarioId(int usuarioId) {
		this.usuarioId = usuarioId;
	}

	public void setId(int idPaciente) {
		this.idPaciente = idPaciente;
	}

}
