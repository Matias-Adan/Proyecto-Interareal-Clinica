package com.clinica.dao;

import java.util.List;

import com.clinica.modelo.Insumo;

public interface IInsumoDao {
	boolean insertar(IInsumoDao i);
	List<IInsumoDao> listar();
	boolean actualizar(IInsumoDao i);
	boolean eliminar(int id);
}