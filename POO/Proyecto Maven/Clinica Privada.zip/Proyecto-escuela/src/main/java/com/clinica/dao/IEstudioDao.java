package com.clinica.dao;

import java.util.List;
import com.clinica.modelo.Estudio;

public interface IEstudioDao {
	boolean insertar(IEstudioDao e);
	List<IEstudioDao> listar();
	boolean actualizar(IEstudioDao e);
	boolean eliminar(int id);
}
