package com.clinica.dao;

import java.util.List;

import com.clinica.modelo.Factura;

public interface IFacturaDao {
	boolean insertar(IFacturaDao f);
	List<IFacturaDao> listar();
	boolean actualizar(IFacturaDao f);
	boolean eliminar(int id);
}
