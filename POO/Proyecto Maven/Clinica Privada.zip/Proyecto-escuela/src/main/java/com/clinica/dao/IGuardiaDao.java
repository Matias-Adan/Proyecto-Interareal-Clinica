package com.clinica.dao;

import java.util.List;

import com.clinica.modelo.Guardia;

public interface IGuardiaDao {
	boolean insertar(IGuardiaDao g);
	List<IGuardiaDao> listar();
	boolean actualizar(IGuardiaDao g);
	boolean eliminar(int id);
}