package com.clinica.dao;

import java.util.List;


import com.clinica.modelo.RolDeUsuario;

public interface IRolDeUsuarioDao {
	boolean insertar(IRolDeUsuarioDao r);
	List<IRolDeUsuarioDao> listar();
	boolean actualizar(IRolDeUsuarioDao r);
	boolean eliminar(int id);
}
