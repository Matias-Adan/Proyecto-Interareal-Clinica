package com.clinica.dao;

import java.util.List;

import com.clinica.modelo.UbicacionPaciente;

public interface IUbicacionPacienteDao {
	boolean insertar(IUbicacionPacienteDao u);
	List<IUbicacionPacienteDao> listar();
	boolean actualizar(IUbicacionPacienteDao u);
	boolean eliminar(int id);
}
