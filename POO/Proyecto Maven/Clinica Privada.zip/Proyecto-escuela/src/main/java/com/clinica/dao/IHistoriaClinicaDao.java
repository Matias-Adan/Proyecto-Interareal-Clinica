package com.clinica.dao;

import java.util.List;

import com.clinica.modelo.HistoriaClinica;

public interface IHistoriaClinicaDao {
	boolean insertar(IHistoriaClinicaDao h);
	List<IHistoriaClinicaDao> listar();
	boolean actualizar(IHistoriaClinicaDao h);
	boolean eliminar(int id);
}
