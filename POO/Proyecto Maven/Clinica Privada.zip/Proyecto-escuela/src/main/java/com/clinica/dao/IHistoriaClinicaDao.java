package com.clinica.dao;

import java.util.List;

import com.clinica.modelo.HistoriaClinica;

public interface IHistoriaClinicaDao {
	boolean insertar(HistoriaClinica h);
	HistoriaClinica buscarPorId(int id);
	List<HistoriaClinica> listar();
	boolean actualizar(HistoriaClinica h);
}
