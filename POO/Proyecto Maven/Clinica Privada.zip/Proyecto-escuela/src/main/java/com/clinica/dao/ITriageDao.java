package com.clinica.dao;

import java.util.List;

import com.clinica.modelo.Triage;

public interface ITriageDao {
	boolean insertar(ITriageDao t);
	List<ITriageDao> listar();
	boolean actualizar(ITriageDao t);
	boolean eliminar(int id);
}
