package com.clinica.dao;

import java.util.List;

import com.clinica.modelo.Receta;

public interface IRecetaDao {
	boolean insertar(IRecetaDao r);
	List<IRecetaDao> listar();
	boolean actualizar(IRecetaDao r);
	boolean eliminar(int id);
}

