package com.clinica.dao;

import java.util.List;

import com.clinica.modelo.Usuario;

public interface IUsuarioDao {
	boolean insertar(IUsuarioDao u);
	List<IUsuarioDao> listar();
	boolean actualizar(IUsuarioDao u);
	boolean eliminar(int id);
}
