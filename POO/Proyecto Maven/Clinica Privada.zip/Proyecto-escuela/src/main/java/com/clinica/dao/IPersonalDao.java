package com.clinica.dao;

import java.util.List;

import com.clinica.modelo.Personal;

public interface IPersonalDao {
	boolean insertar(IPersonalDao p);
	List<IPersonalDao> listar();
	boolean actualizar(IPersonalDao p);
	boolean eliminar(int id);
}
