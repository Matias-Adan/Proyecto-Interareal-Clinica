package com.clinica.dao;

import java.util.List;

import com.clinica.modelo.ObraSocial;

public interface IObraSocialDao {
	boolean insertar(IObraSocialDao o);
	List<IObraSocialDao> listar();
	boolean actualizar(IObraSocialDao o);
	boolean eliminar(int id);
}