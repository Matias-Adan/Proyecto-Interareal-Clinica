package com.clinica.config;
import java.sql.Connection;
import java.sql.DriverManager;

public class Conexion {
    private static final String URL = "http://localhost/phpmyadmin/index.php?route=/database/structure&db=clinica";
    private static final String USER = "root";
    private static final String PASS = "";
    
    public static Connection getConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(URL, USER, PASS);
        } catch (Exception e) {
            System.out.println("Error conexión: " + e.getMessage());
            return null;
        }
    }
}