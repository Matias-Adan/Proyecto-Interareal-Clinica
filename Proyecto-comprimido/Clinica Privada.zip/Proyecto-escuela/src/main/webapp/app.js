
const API_BASE = '/Proyecto_escuela';

async function verificarSesion() {
    try {
        const res = await fetch(`${API_BASE}/AuthServlet`);
        const data = await res.json();

        if (!data.autenticado) {
            window.location.href = 'login.html';
            return;
        }

        // Si el usuario es Administrador (idRol === 1), mostramos controles especiales
        if (data.usuario && data.usuario.idRol === 1) {
            const linkAdmin = document.getElementById('link-admin');
            if (linkAdmin) linkAdmin.classList.remove('hidden');
        }
    } catch (e) {
        window.location.href = 'login.html';
    }
}

async function cerrarSesion() {
    await fetch(`${API_BASE}/AuthServlet?action=logout`, { method: 'POST' });
    window.location.href = 'login.html';
}

async function borradoLogico(id, servlet) {
    if (!confirm('¿Desea realizar el borrado lógico (desactivar)?')) return;
    await fetch(`${API_BASE}/${servlet}?id=${id}&fisico=false`, { method: 'DELETE' });
    location.reload();
}

async function borradoFisico(id, servlet) {
    if (!confirm('¡ATENCIÓN! Esto eliminará el registro permanentemente de la base de datos.')) return;
    await fetch(`${API_BASE}/${servlet}?id=${id}&fisico=true`, { method: 'DELETE' });
    location.reload();
}