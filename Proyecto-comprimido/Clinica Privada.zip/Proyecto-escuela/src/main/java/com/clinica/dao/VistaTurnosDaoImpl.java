package com.clinica.dao;

import com.clinica.config.Conexion;
import com.clinica.modelo.VistaTurnos;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;

public class VistaTurnosDaoImpl implements IVistaTurnosDao {

    @Override
    public List<VistaTurnos> listar() {
        List<VistaTurnos> lista = new ArrayList<>();
        String sql = "{CALL sp_seleccionar(\"turnos\")}";
        
        try (Connection con = Conexion.getInstancia().getConexion();
             CallableStatement cs = con.prepareCall(sql);
             ResultSet rs = cs.executeQuery()) {

            while (rs.next()) {
                Date sqlDate = rs.getDate("fecha");
                Time sqlHoraInicio = rs.getTime("horaInicio");
                Time sqlHoraFin = rs.getTime("horaFin");
                
                VistaTurnos vt = new VistaTurnos(
                        rs.getInt("idTurno"),
                        sqlDate != null ? sqlDate.toLocalDate() : null,
                        sqlHoraInicio != null ? sqlHoraInicio.toLocalTime() : null,
                        sqlHoraFin != null ? sqlHoraFin.toLocalTime() : null,
                        rs.getString("estado"),
                        rs.getString("motivo"),
                        rs.getInt("pacienteId"),
                        rs.getInt("medicoId"),
                        rs.getInt("especialidadId"),
                        rs.getInt("consultorioId")
                );
                lista.add(vt);
            }
        } catch (SQLException e) {
            System.err.println("❌ Error al listar vista de turnos: " + e.getMessage());
        }
        return lista;
    }

    @Override
    public VistaTurnos buscarPorId(int id) {
        VistaTurnos vt = null;
        String sql = "{CALL sp_turnos_listar(?)}";

        try (Connection con = Conexion.getInstancia().getConexion();
             CallableStatement cs = con.prepareCall(sql)) {
            
            cs.setInt(1, id);
            try (ResultSet rs = cs.executeQuery()) {
                if (rs.next()) {
                    Date sqlDate = rs.getDate("fecha");
                    Time sqlHoraInicio = rs.getTime("horaInicio");
                    Time sqlHoraFin = rs.getTime("horaFin");
                    
                    vt = new VistaTurnos(
                            rs.getInt("idTurno"),
                            sqlDate != null ? sqlDate.toLocalDate() : null,
                            sqlHoraInicio != null ? sqlHoraInicio.toLocalTime() : null,
                            sqlHoraFin != null ? sqlHoraFin.toLocalTime() : null,
                            rs.getString("estado"),
                            rs.getString("motivo"),
                            rs.getInt("pacienteId"),
                            rs.getInt("medicoId"),
                            rs.getInt("especialidadId"),
                            rs.getInt("consultorioId")
                    );
                }
            }
        } catch (SQLException e) {
            System.err.println("❌ Error al buscar en la vista de turnos: " + e.getMessage());
        }
        return vt;
    }
}