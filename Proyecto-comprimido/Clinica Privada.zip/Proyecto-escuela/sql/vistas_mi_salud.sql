-- ---------------------------------------------------------------------------
-- Vistas para la sección "Mi salud" de la vista del paciente.
--
-- Resumen de lo que ve el paciente:
--   * Sus alergias actuales.
--   * Sus recetas con el detalle de cada medicamento.
--
-- Todas las vistas se filtran por el DNI del paciente desde el DAO.
-- ---------------------------------------------------------------------------

-- ---------------------------------------------------------------------------
-- Alergias actuales del paciente.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW `v_mis_alergias` AS
SELECT
    u.`idUsuario`                                    AS `paciente_id`,
    u.`dni`                                          AS `paciente_dni`,
    CONCAT(u.`nombre`, ' ', u.`apellido`)            AS `paciente_nombre`,
    ap.`idAlergiaPaciente`                           AS `id_alergia_paciente`,
    a.`idAlergia`                                    AS `id_alergia`,
    a.`nombre`                                       AS `alergia_nombre`,
    a.`descripcion`                                  AS `alergia_descripcion`
FROM `alergiapaciente` ap
JOIN `usuarios` u  ON u.`idUsuario` = ap.`pacienteId`
JOIN `alergias` a  ON a.`idAlergia` = ap.`alergiaId`
ORDER BY a.`nombre`;

-- ---------------------------------------------------------------------------
-- Recetas del paciente con el detalle de cada medicamento.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW `v_mis_recetas_detalle` AS
SELECT
    u.`idUsuario`                                     AS `paciente_id`,
    u.`dni`                                           AS `paciente_dni`,
    CONCAT(u.`nombre`, ' ', u.`apellido`)             AS `paciente_nombre`,
    r.`idReceta`                                      AS `id_receta`,
    r.`fecha`                                         AS `fecha`,
    r.`indicacion`                                    AS `indicacion`,
    d.`idDetalle`                                     AS `id_detalle`,
    d.`cantidad`                                      AS `cantidad`,
    d.`dosis`                                         AS `dosis`,
    d.`frecuencia`                                    AS `frecuencia`,
    d.`duracion`                                      AS `duracion`,
    a.`idArticulo`                                    AS `id_articulo`,
    a.`nombre`                                        AS `articulo_nombre`,
    a.`presentacion`                                  AS `presentacion`,
    c.`idConsulta`                                    AS `id_consulta`,
    c.`fechaHora`                                     AS `fecha_consulta`,
    c.`diagnostico`                                   AS `diagnostico`,
    CONCAT(m.`nombre`, ' ', m.`apellido`)             AS `medico_nombre`
FROM `recetas` r
JOIN `detallesreceta` d       ON d.`recetaId` = r.`idReceta`
JOIN `articulos` a            ON a.`idArticulo` = d.`articuloId`
JOIN `consultas` c            ON c.`idConsulta` = r.`consultaId`
JOIN `historiasclinicas` h    ON h.`idHistoria` = c.`historiaId`
JOIN `usuarios` u             ON u.`idUsuario` = h.`pacienteId`
LEFT JOIN `usuarios` m        ON m.`idUsuario` = c.`medicoId`
ORDER BY r.`fecha` DESC, r.`idReceta` DESC, d.`idDetalle` ASC;
