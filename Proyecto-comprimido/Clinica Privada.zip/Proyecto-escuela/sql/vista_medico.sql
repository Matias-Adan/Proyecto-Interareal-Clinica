-- ---------------------------------------------------------------------------
-- Vistas para la sección "Agenda y pacientes" de la vista del médico.
--
-- Resumen de lo que ve el profesional:
--   * Sus turnos asignados (los que tienen su medicoId).
--   * Los pacientes que están actualmente en el triage.
--
-- El DAO filtra los turnos por el id del médico logueado (medico_id) y toma
-- el triage directamente de la vista. Ejecutar una sola vez sobre la base
-- `clinica`: las vistas son idempotentes (CREATE OR REPLACE).
-- ---------------------------------------------------------------------------

-- ---------------------------------------------------------------------------
-- Turnos del médico con los datos del paciente y del consultorio.
-- Los alias coinciden con los que ya usa VistaTurnosDaoImpl para reutilizar
-- el modelo VistaTurnos del proyecto.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW `v_turnos_medico` AS
SELECT
    t.`idTurno`                                 AS `idTurno`,
    t.`medicoId`                                AS `medico_id`,
    t.`fecha`                                   AS `fecha`,
    t.`horaInicio`                              AS `horaInicio`,
    t.`horaFin`                                 AS `horaFin`,
    t.`estado`                                  AS `estado_turno`,
    t.`motivo`                                  AS `motivo`,
    CONCAT(md.`nombre`, ' ', md.`apellido`)     AS `medico_nombre`,
    p.`idUsuario`                               AS `paciente_id`,
    CONCAT(p.`nombre`, ' ', p.`apellido`)       AS `paciente_nombre`,
    p.`dni`                                     AS `paciente_dni`,
    c.`numero`                                  AS `consultorio_numero`
FROM `turnos` t
JOIN `usuarios` md      ON md.`idUsuario` = t.`medicoId`
JOIN `usuarios` p       ON p.`idUsuario` = t.`pacienteId`
LEFT JOIN `consultorio` c ON c.`idConsultorio` = t.`consultorioId`;

-- ---------------------------------------------------------------------------
-- Pacientes que continúan en el triage.
--
-- Se excluyen los estados que se consideran cerrados (el paciente ya fue
-- atendido, dado de alta o derivado). Como `triage.estado` es texto libre,
-- si el proyecto empieza a usar otro estado final, alcanza con agregarlo a
-- la lista del NOT IN.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW `v_triage_actual` AS
SELECT
    tr.`idTriage`                               AS `idTriage`,
    tr.`fecha`                                  AS `fecha`,
    tr.`prioridad`                              AS `prioridad`,
    tr.`estado`                                 AS `estado`,
    tr.`observacion`                            AS `observacion`,
    tr.`pacienteId`                             AS `paciente_id`,
    CONCAT(p.`nombre`, ' ', p.`apellido`)       AS `paciente_nombre`,
    p.`dni`                                     AS `paciente_dni`,
    tr.`consultorioId`                          AS `consultorio_id`,
    c.`numero`                                  AS `consultorio_numero`,
    tr.`enfermeroId`                            AS `enfermero_id`,
    CONCAT(e.`nombre`, ' ', e.`apellido`)       AS `enfermero_nombre`
FROM `triage` tr
JOIN `usuarios` p           ON p.`idUsuario` = tr.`pacienteId`
LEFT JOIN `consultorio` c   ON c.`idConsultorio` = tr.`consultorioId`
LEFT JOIN `usuarios` e      ON e.`idUsuario` = tr.`enfermeroId`
WHERE tr.`estado` IS NULL
   OR UPPER(TRIM(tr.`estado`)) NOT IN (
        'ATENDIDO', 'ALTA', 'FINALIZADO', 'EGRESADO', 'DERIVADO', 'RESUELTO', 'ANULADO'
   );
