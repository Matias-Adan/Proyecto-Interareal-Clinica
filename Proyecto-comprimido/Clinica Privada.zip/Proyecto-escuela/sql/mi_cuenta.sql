-- ---------------------------------------------------------------------------
-- Sección "Mi cuenta".
--
-- La vista es única y reutilizable: sirve para la vista de paciente, la de
-- médico y la de administrador. El DAO la filtra por DNI o por idUsuario y
-- el campo `rol` indica qué es la cuenta (Paciente, Médico, Administrador...).
--
-- Ejecutar una sola vez sobre la base `clinica`. Es idempotente.
-- ---------------------------------------------------------------------------

-- ---------------------------------------------------------------------------
-- Fecha de alta de la cuenta.
--
-- La tabla `usuarios` no guardaba cuándo se creó la cuenta. Se agrega con
-- valor por defecto CURRENT_TIMESTAMP para que los usuarios nuevos la reciban
-- automáticamente (sp_usuarios_insertar no necesita cambios).
--
-- Nota: los usuarios que ya existían quedan con la fecha en que se ejecutó
-- esta migración, porque su fecha real de alta no está registrada.
-- ---------------------------------------------------------------------------
ALTER TABLE `usuarios`
    ADD COLUMN IF NOT EXISTS `fechaAlta` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    AFTER `flagBorrado`;

-- ---------------------------------------------------------------------------
-- Datos de la cuenta del usuario logueado.
--
-- `rol` repite la prioridad de AutorizacionService.rolPrincipal:
-- admin > médico > enfermero > recepcionista > paciente.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW `v_mi_cuenta` AS
SELECT
    u.`idUsuario`                                   AS `usuario_id`,
    u.`dni`                                         AS `dni`,
    u.`nombre`                                      AS `nombre`,
    u.`apellido`                                    AS `apellido`,
    CONCAT(u.`nombre`, ' ', u.`apellido`)           AS `nombre_completo`,
    u.`email`                                       AS `email`,
    u.`telefono`                                    AS `telefono`,
    u.`obraSocialId`                                AS `obra_social_id`,
    COALESCE(o.`nombre`, 'Sin obra social')         AS `obra_social`,
    o.`numeroConvenio`                              AS `numero_convenio`,
    o.`cobertura`                                   AS `cobertura`,
    rr.`idRol`                                      AS `rol_id`,
    COALESCE(rr.`nombre`, 'Sin rol')                AS `rol`,
    u.`fechaAlta`                                   AS `fecha_alta`
FROM `usuarios` u
LEFT JOIN `obrassociales` o
       ON o.`idObraSocial` = u.`obraSocialId`
LEFT JOIN (
    SELECT asignacion.`usuarioId`,
           r.`idRol`,
           r.`nombre`,
           ROW_NUMBER() OVER (
               PARTITION BY asignacion.`usuarioId`
               ORDER BY CASE r.`idRol`
                            WHEN 1 THEN 1  -- Administrador
                            WHEN 2 THEN 2  -- Médico
                            WHEN 3 THEN 3  -- Enfermero
                            WHEN 4 THEN 4  -- Recepcionista
                            WHEN 5 THEN 5  -- Paciente
                            ELSE 99
                        END,
                        r.`idRol`
           ) AS `orden`
    FROM `roldeusuario` asignacion
    JOIN `roles` r ON r.`idRol` = asignacion.`rolId`
) rr ON rr.`usuarioId` = u.`idUsuario` AND rr.`orden` = 1
WHERE u.`flagBorrado` = 0;
