-- ---------------------------------------------------------------------------
-- Vistas para la vista del administrador.
--
-- Resumen de lo que ve el administrador:
--   * Los usuarios activos (flagBorrado = 0) con su obra social.
--   * Todos los artículos, marcando cuáles están en stock bajo.
--
-- El DAO completa los usuarios con sus roles desde roldeusuario/roles.
-- Ejecutar una sola vez sobre la base `clinica`. Es idempotente.
-- ---------------------------------------------------------------------------

-- ---------------------------------------------------------------------------
-- Usuarios activos.
--
-- La vista no expone la contraseña. Los roles se resuelven en el DAO para
-- poder mostrar también el id de la asignación (necesario para quitarla).
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW `v_admin_usuarios` AS
SELECT
    u.`idUsuario`                                   AS `usuario_id`,
    u.`nombre`                                      AS `nombre`,
    u.`apellido`                                    AS `apellido`,
    CONCAT(u.`nombre`, ' ', u.`apellido`)           AS `nombre_completo`,
    u.`dni`                                         AS `dni`,
    u.`email`                                       AS `email`,
    u.`telefono`                                    AS `telefono`,
    u.`obraSocialId`                                AS `obra_social_id`,
    COALESCE(o.`nombre`, 'Sin obra social')         AS `obra_social`,
    u.`fechaAlta`                                   AS `fecha_alta`
FROM `usuarios` u
LEFT JOIN `obrassociales` o ON o.`idObraSocial` = u.`obraSocialId`
WHERE u.`flagBorrado` = 0;

-- ---------------------------------------------------------------------------
-- Todos los artículos con la marca de stock bajo.
--
-- Se apoya en la vista existente `v_articulos_bajo_stock_minimo` para no
-- duplicar la regla de negocio (stockActual <= stockMinimo). Los artículos
-- que no aparecen en esa vista quedan con stock_bajo = 0.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW `v_admin_articulos` AS
SELECT
    a.`idArticulo`                                  AS `idArticulo`,
    a.`nombre`                                      AS `nombre`,
    a.`descripcion`                                 AS `descripcion`,
    a.`presentacion`                                AS `presentacion`,
    a.`tipoArticulo`                                AS `tipoArticulo`,
    a.`stockActual`                                 AS `stockActual`,
    a.`stockMinimo`                                 AS `stockMinimo`,
    CASE WHEN s.`idArticulo` IS NOT NULL THEN 1 ELSE 0 END AS `stock_bajo`,
    COALESCE(s.`cantidad_a_reponer`, 0)             AS `cantidad_a_reponer`
FROM `articulos` a
LEFT JOIN `v_articulos_bajo_stock_minimo` s
       ON s.`idArticulo` = a.`idArticulo`;
