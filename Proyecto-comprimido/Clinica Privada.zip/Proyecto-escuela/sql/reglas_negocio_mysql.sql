-- =====================================================================
--  Proyecto-escuela-corregido
--  Script de apoyo para las reglas de negocio (MySQL 8.0.16 o superior)
--
--  IMPORTANTE:
--    * Ejecutar sobre la base de datos del sistema (por defecto: clinica).
--    * Es idempotente: se puede ejecutar más de una vez.
--    * No reemplaza los procedimientos almacenados existentes (sp_*).
--
--  Qué agrega:
--    1) Tabla auditoria_clinica (obligatoria para corregir datos clínicos).
--    2) Índices únicos de DNI, email y rol por usuario.
--    3) Restricciones CHECK para que el stock y los importes no sean negativos.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1) Auditoría de datos clínicos
--    Toda corrección de consulta / historia / triage / alergia-paciente
--    guarda aquí el estado anterior en JSON.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS auditoria_clinica (
    idAuditoria      INT AUTO_INCREMENT PRIMARY KEY,
    tabla            VARCHAR(60)  NOT NULL,
    registroId       INT          NOT NULL,
    accion           VARCHAR(30)  NOT NULL,
    datosAnteriores  LONGTEXT     NULL,
    usuarioId        INT          NOT NULL,
    fechaCambio      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_auditoria_tabla (tabla, registroId),
    INDEX idx_auditoria_usuario (usuarioId),
    INDEX idx_auditoria_fecha (fechaCambio)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

-- ---------------------------------------------------------------------
-- 2) Unicidad e integridad
--    Se aplican de forma condicional para no fallar si ya existen.
-- ---------------------------------------------------------------------
DELIMITER $$

DROP PROCEDURE IF EXISTS aplicar_reglas_negocio $$

CREATE PROCEDURE aplicar_reglas_negocio()
BEGIN
    -- DNI único
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.STATISTICS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'usuarios'
          AND INDEX_NAME = 'ux_usuarios_dni'
    ) THEN
        ALTER TABLE usuarios ADD UNIQUE INDEX ux_usuarios_dni (dni);
    END IF;

    -- Email único
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.STATISTICS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'usuarios'
          AND INDEX_NAME = 'ux_usuarios_email'
    ) THEN
        ALTER TABLE usuarios ADD UNIQUE INDEX ux_usuarios_email (email);
    END IF;

    -- Un usuario no puede tener el mismo rol dos veces
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.STATISTICS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'roldeusuario'
          AND INDEX_NAME = 'ux_roldeusuario_usuario_rol'
    ) THEN
        ALTER TABLE roldeusuario
            ADD UNIQUE INDEX ux_roldeusuario_usuario_rol (usuarioId, rolId);
    END IF;

    -- El stock nunca puede quedar negativo
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.TABLE_CONSTRAINTS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'articulos'
          AND CONSTRAINT_NAME = 'chk_articulos_stock_no_negativo'
    ) THEN
        ALTER TABLE articulos
            ADD CONSTRAINT chk_articulos_stock_no_negativo
            CHECK (stockActual >= 0 AND stockMinimo >= 0);
    END IF;

    -- Una cantidad de detalle de receta siempre es positiva
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.TABLE_CONSTRAINTS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'detallesreceta'
          AND CONSTRAINT_NAME = 'chk_detallesreceta_cantidad_positiva'
    ) THEN
        ALTER TABLE detallesreceta
            ADD CONSTRAINT chk_detallesreceta_cantidad_positiva
            CHECK (cantidad > 0);
    END IF;

    -- El importe de una factura no puede ser negativo
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.TABLE_CONSTRAINTS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'facturas'
          AND CONSTRAINT_NAME = 'chk_facturas_importe_no_negativo'
    ) THEN
        ALTER TABLE facturas
            ADD CONSTRAINT chk_facturas_importe_no_negativo
            CHECK (importeTotal >= 0);
    END IF;
END$$

DELIMITER ;

CALL aplicar_reglas_negocio();
DROP PROCEDURE aplicar_reglas_negocio;

-- ---------------------------------------------------------------------
-- 3) Consultas de verificación (opcionales)
-- ---------------------------------------------------------------------
-- SELECT * FROM auditoria_clinica ORDER BY idAuditoria DESC;
--
-- SELECT TABLE_NAME, INDEX_NAME, GROUP_CONCAT(COLUMN_NAME ORDER BY SEQ_IN_INDEX) AS columnas
-- FROM information_schema.STATISTICS
-- WHERE TABLE_SCHEMA = DATABASE() AND NON_UNIQUE = 0
-- GROUP BY TABLE_NAME, INDEX_NAME
-- ORDER BY TABLE_NAME;
